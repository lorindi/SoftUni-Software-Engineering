from project.vehicle import Vehicle

class Motorcycle(Vehicle):
    pass
    # def __init__(self, fuel, horse_power):
    #     super().__init(fuel, horse_power)